var hm = require('header-metadata');
var sm = require('service-metadata');
var crypto = require('crypto');
var headers = hm.current;
	
var path = sm.getVar('var://service/URI');
console.notice('path:\n' +  path);


if(path.includes('/api/p/update_status_policy')) {
	
	var beforeHashValue = headers.get('beforeHashValue');
	var keyHmac = headers.get('hmacKey');
	var secretkey = new Buffer(33);
    secretkey.write(keyHmac)
	var hmac = crypto.createHmac('hmac-sha256', secretkey);
	var hashResult = hmac.update(beforeHashValue).digest('hex');
	var newUri = path + '&checkSum=' + hashResult;
	sm.setVar('var://service/URI', newUri);
	console.notice('Final request to backend URL : ' + sm.URLOut + '\nWith Header params:\n' +  JSON.stringify(headers));
	

} else if (path.includes('/api/p/input-order')) {
	session.input.readAsJSON (function (error, json) {
	   if (error) {
			throw error;
	   }

		console.notice('original bank/contracts body request :\n' +  JSON.stringify(json)); 
		var beforeHashValue = headers.get('beforeHashValue');
	var keyHmac = headers.get('hmacKey');
	var secretkey = new Buffer(33);
    secretkey.write(keyHmac)
	var hmac = crypto.createHmac('hmac-sha256', secretkey);
	var hashResult = hmac.update(beforeHashValue).digest('hex');
	json.signature = hashResult;
		
        console.notice('Final request to backend URL : ' + sm.URLOut + '\nWith Header params:\n' +  JSON.stringify(headers));
		console.notice('and Body payload:\n' + JSON.stringify(json));
		session.output.write(json);  
	});  	

} else {
	console.error('API: ' + path + ' Not supported!');
}
