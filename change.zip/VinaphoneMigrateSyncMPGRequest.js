var hm = require('header-metadata');
var sm = require('service-metadata');
var crypto = require('crypto');
var headers = hm.current;
	
var path = sm.getVar('var://service/URI');
console.notice('path:\n' +  path);


session.input.readAsJSON (function (error, json) {
	if (error) {
		throw error;
	}

	console.notice('Begin request to backend URL : ' + sm.URLOut + '\nWith Header params:\n' +  JSON.stringify(headers));
	console.notice('Begin Body payload:\n' + JSON.stringify(json));
	var beforeHashValue = headers.get('beforeHashValue');
	
	var hashResult = crypto.createHash('sha256').update(beforeHashValue).digest('hex');
	
	headers.set('Authorization','Bearer ' + hashResult);
	console.notice('Final request to backend URL : ' + sm.URLOut + '\nWith Header params:\n' +  JSON.stringify(headers));
	console.notice('Final Body payload:\n' + JSON.stringify(json));
	session.output.write(json);  
});  	

