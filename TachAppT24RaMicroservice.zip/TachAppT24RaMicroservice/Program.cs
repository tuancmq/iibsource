﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;

namespace TachAppT24RaMicroservice
{
    class Program
    {

        public class MyObject
        {
            public string appName { get; set; }
            public string queueName { get; set; }

            public string labelName { get; set; }

            public List<MyObject2> fileNeedChangeQueue { get; set; }

        }

        public class MyObject2
        {
            public string fileNeedChangeQueueName { get; set; }
            public string[] fileNeedChangeQueueNameContent { get; set; }

            public string newLine { get; set; }
        }

        public class FileAndContent
        {
            public string fileName { get; set; }
            public string fileContent { get; set; }
            public string[] fileContentLine { get; set; }


        }
        static void Main(string[] args)

        {

     
            FindFileByLabel();


        }

        public static void CopyFileToNewApp()
        {
            string trgSourcePath = @"D:\2024\ChiaBanh_Process";
            string[] allLines = System.IO.File.ReadAllLines(@"D:\Src\ToolByTuanCMQ2024\ToolByTuanCMQ\TachAppT24RaMicroservice\TextFile1.txt");

            foreach (var item in allLines)
            {
                string[] params1 = item.Split("	");
                string fileName = params1[0];
                string function = params1[1];
                string path = params1[2];

                if (function.Contains(","))
                {
                    path = trgSourcePath + @"\adpt24in-" + path + "-txn\\";
                }
                else
                {
                    path = trgSourcePath + @"\adpt24in-" + path + "-enq\\";
                }

                string fileNameOnly = Path.GetFileName(fileName);
                string operationInIIB = fileNameOnly.Split("_")[1];
                string dics = Path.GetDirectoryName(fileName);

                Directory.CreateDirectory(path);
                try
                {
                    File.Copy(fileName, path + fileNameOnly, true);
                }
                catch (Exception)
                {
                    Console.WriteLine(fileName + "\n");
                }

                int i = 0;

                DirectoryInfo di = new DirectoryInfo(dics);
                FileInfo[] filesESQL = di.GetFiles("*.esql");
                foreach (FileInfo esql in filesESQL)
                {

                    string fileNameOnly2 = Path.GetFileName(esql.FullName);
                    if (fileNameOnly2.Contains(operationInIIB))
                    {
                        try
                        {
                            File.Copy(esql.FullName, path + fileNameOnly2, true);
                        }
                        catch (Exception)
                        {

                            Console.WriteLine(fileName + "\n");
                        }


                    }
                }
            }
        }


        public static void FindFileByLabel()
        {

            string[] allLines = System.IO.File.ReadAllLines(@"D:\Src\ToolByTuanCMQ2024\ToolByTuanCMQ\TachAppT24RaMicroservice\TextFile2.txt");


            List<string> listQueue = new List<string>();
            List<MyObject> listObject = new List<MyObject>();
            foreach (var item in allLines)
            {
                string[] params1 = item.Split("/");

                string fileMapping = params1[0];
                string fileGoc = params1[1];




                string fileName = params1[0];
                string function = params1[1];
                string rawFileName = Path.GetFileName(params1[0]);


                XmlDocument mainFlow = new XmlDocument();
                mainFlow.Load(function);
                XmlNode rootMainFlow = mainFlow.DocumentElement;
                XmlNodeList nodeListmainFlow = rootMainFlow.SelectNodes("//@queueName");
                string queueName = "";
                foreach (XmlNode node in nodeListmainFlow)
                {
                     queueName += node.InnerText;

                    


                }


                XmlDocument mappingFlow = new XmlDocument();
                mappingFlow.Load(fileMapping);
                XmlNode root = mappingFlow.DocumentElement;
                XmlNodeList nodeList = root.SelectNodes("//@labelName");
                foreach (XmlNode node in nodeList)
                {
                    string functionName = node.InnerText;


                    listQueue.Add(rawFileName + "@" + queueName + "@" +  functionName);
                    MyObject myobject = new MyObject();
                    myobject.appName = rawFileName;
                    myobject.queueName = queueName;
                    myobject.labelName = functionName;
                    listObject.Add(myobject);

                }


               

            }



            string dirScanner = @"D:\Src\cp4i\sit-daily\it-cais\ace";



            string[] allOut = Directory.GetDirectories(dirScanner, "*out*");
            string[] allSrv = Directory.GetDirectories(dirScanner, "*srv*");
            string[] api = Directory.GetDirectories(dirScanner, "*oapi*");
            string[] iapi = Directory.GetDirectories(dirScanner, "*iapi*");
            List<string> allFolderNeedscan = new List<string>();
            List<string> allFileListNeedScan = new List<string>();
            allFolderNeedscan.AddRange(allOut);
            allFolderNeedscan.AddRange(allSrv);
            allFolderNeedscan.AddRange(api);
            allFolderNeedscan.AddRange(iapi);

            foreach (string folder in allFolderNeedscan)
            {

                string[] listFile = Directory.GetFiles(folder, "*.esql", SearchOption.AllDirectories);
                allFileListNeedScan.AddRange(listFile);



            }

            List<FileAndContent> listFileAndContent = new List<FileAndContent>();
            foreach (string file in allFileListNeedScan)
            {
                FileAndContent iA = new FileAndContent();
                iA.fileName = file;
                iA.fileContent = File.ReadAllText(file);
                iA.fileContentLine = File.ReadAllLines(file);
                listFileAndContent.Add(iA);
            }


           foreach (MyObject myobject in listObject)
            {




                myobject.fileNeedChangeQueue = new List<MyObject2>();
   

                
                foreach (var fileContent in listFileAndContent)
                {
                    //string[] lines = File.ReadAllLines(file);
                    //string firstOccurrence = lines.FirstOrDefault(l => l.Contains(myobject.labelName));
                    if (fileContent.fileContent.Contains(myobject.labelName))
                    {
                        MyObject2 myobject2 = new MyObject2();
                        myobject2.fileNeedChangeQueueName = fileContent.fileName;
                        myobject2.fileNeedChangeQueueNameContent = fileContent.fileContentLine;
                        myobject.fileNeedChangeQueue.Add(myobject2);
                    }

                }
                    
                


            }


            foreach (var item in listObject)
            {
                foreach (var item2 in item.fileNeedChangeQueue)
                {
                    Console.WriteLine(item.appName + "      " + item.queueName + "      " +  item.labelName + "      " + item2.fileNeedChangeQueueName);
                    Console.WriteLine("\n");
                }
                
             
            }

            Console.WriteLine("========================================================================");

            foreach (var item in listObject)
            {
                foreach (var item2 in item.fileNeedChangeQueue)
                {
                    bool isContentContainsQueueName = false;
                    Console.WriteLine("Processing :" + item2.fileNeedChangeQueueName );
                    foreach (var item3 in item2.fileNeedChangeQueueNameContent)
                    {
                        
                        if (item3.Contains("queueName") && !item3.ToUpper().Contains("WAY4IN"))
                        {
                            
                            isContentContainsQueueName = true;
                            Console.WriteLine("\tFind a row :" + item3);
                            Console.WriteLine("\tReplace with : OutputLocalEnvironment.Destination.MQ.DestinationData[1].queueName = '" + item.queueName + "';");
                        }
                        else if (item3.Contains("createDestination") && !item3.ToUpper().Contains("WAY4IN"))
                        {
                            isContentContainsQueueName = true;
                            Console.WriteLine("\tFind a row :" + item3);
                            Console.WriteLine("\tReplace with : CALL createDestination(OutputLocalEnvironment,trgRoot, '" + item.queueName + "',NULL));");
                        }
                    }
                    if (!isContentContainsQueueName)
                    {
                        Console.WriteLine("\tNO QUEUE NAME DETECT IN FILE :" + item2.fileNeedChangeQueueName );
                    }
                 
                }


            }



        }
    }
}
