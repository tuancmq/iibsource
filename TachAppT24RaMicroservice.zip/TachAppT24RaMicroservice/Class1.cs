﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace TachAppT24RaMicroservice
{
    class Class1
    {

    }
}
