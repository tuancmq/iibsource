StartTransaction.subflow
========================

Subflow is used at the begining of business transaction.

Input terminal of the subflow takes message in XMLNSC domain.

Output terminal of the subflow returns message of next structure:

- *MQMD*
- *XMLNSC*
- *Environment*
   - *Variables*
      - *initialRequest* - the request that received at the begining of current local transaction
         - *MQMD*
         - *XMLNSC*
      - *transactionContext*
         - *localTransaction* - local transaction id (if event monitoring is enabled)
      	 - *parentTransaction* - parent transaction id (if event monitoring is enabled)
      	 - *globalTransaction* - global transaction id (if event monitoring is enabled)
      	 - *operation* - current operation name
      	 - *HTTPReplyIdentifier* - keep the `LocalEnvironment.Destination.SOAP.Reply.ReplyIdentifier` in case if current local transaction started with
      	 `SOAPInput` or `HTTPInput`

ContinueParentTransaction.subflow
=================================

Subflow is used at the begining of response Message Flow.

Output terminal of the subflow returns message of next structure:

- *MQMD*
- *XMLNSC*
- *Environment*
   - *Variables*
      - *initialRequest* - the request that received at the begining of current local transaction
         - *MQMD*
         - *XMLNSC*
      - *callbackRequest* - the source request for response
         - *MQMD*
         - *XMLNSC*
      - *transactionContext*
         - *localTransaction* - local transaction id
          - *parentTransaction* - parent transaction id
          - *globalTransaction* - global transaction id
          - *operation* - current operation name
          - *HTTPReplyIdentifier* - keep the `LocalEnvironment.Destination.SOAP.Reply.ReplyIdentifier` in case if current local transaction started with
          `SOAPInput` or `HTTPInput`

When producer send a response it should set response.MQMD.CorrelId = request.MQMD.MsgId

CreateChildTransaction.subflow
==============================

Subflow is used to send request to IIB any services (that is creating new business transaction)

Structure of the message sent to destination queue:

- *MQMD*
- *MQRFH2*
   - *usr*
      - *transactionContext*
      	 - *parentTransaction* - value from `Environment.Variables.transactionContext.localTransaction`
      	 - *globalTransaction* - value from `Environment.Variables.transactionContext.globalTransaction`
- *XMLNSC*

Structure of the message sent to the callback queue:

- *MQMD*
   - ...
   - *MsgId* - MQMD.MsgId of sent request
   - *CorrelId* - MQMD.MsgId of sent request
- *XMLNSC*
   - *CallbackData*
      - *Properties* - properties of sent request
      - *MQMD* - MQMD of sent request
      - *MQRFH2* - MQRFH2 of sent request
      - *root* - XMLNSC of sent request
      - *initialRequest* - initial request of current local transaction
      - *Environment* - Environment of current Message Flow
         - *Variables*
            - ~~*initialRequest*~~
            - ~~*callbackRequest*~~
            - *transactionContext*
              - *localTransaction*
      	      - *parentTransaction*
      	      - *globalTransaction*
      	      - *operation*
      	      - *HTTPReplyIdentifier*               